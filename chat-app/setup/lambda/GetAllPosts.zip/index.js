'use strict';

exports.handler = (event, context, callback) => {
  
  var AWS = require('aws-sdk'); 
  var dynamoDB = new AWS.DynamoDB({apiVersion: '2012-08-10'});
  var params = {
    TableName: 'Posts',
    Select: 'ALL_ATTRIBUTES'
  };
  
  dynamoDB.scan(params, function(err, data) {
    if (err) {
      callback(null, {
        "result": "Failure",
        "message": "Could not get items from Posts table."
      });
    } else {
      /* Transform this:
      {
        "Items":[
            {
                "Alias": {"S":"Bob"},
                "Timestamp": {"S":"1491857366"},
                "Message": {"S":"Is anyone there?"}
            },
            {
                "Alias": {"S":"Mary"},
                "Timestamp": {"S":"1491857367"},
                "Message":{"S":"I am here!"}
            }
        ],
        "Count": 2,
        "ScannedCount": 2
      }
      
      To this:
      
      {
          "posts": [
            {
                "post": {
                    "user_name": "Bob",
                    "message": "Is anyone there?",
                    "timestamp": "1491857366"
                }
            },
            {
                "post": {
                    "user_name": "Mary",
                    "message": "I am here!",
                    "timestamp": "1491857367"
                }
            }
          ]
      }
      */
      var mappedData = "{\"posts\":[";
      
      for(var i = 0; i < data.Items.length; i++) {
          mappedData += "{"
          mappedData += "\"post\": {";
          mappedData += "\"user_name\": \"" + data.Items[i].Alias["S"] + "\",";
          mappedData += "\"message\": \"" + data.Items[i].Message["S"] + "\",";
          mappedData += "\"posted\": \"" + data.Items[i].Timestamp["S"] + "\"";
          mappedData += "}";
          
          if (i == data.Items.length - 1) {
            mappedData += "}";  
          } else {
            mappedData += "},";
          }
      }
      
      mappedData += "]}";
      callback(null, mappedData);
    }
  });
};
// Verifies an access token provided by Cognito for signing in to the 
// ChatRoomPool Cognito user pool.
// To get an access token, call SignInCognitoUser.
// Input:
/*
{
  "AccessToken": "a1b2.c3d4.e5g6"
}
*/
// Output: 
// If successful, returns:
/*
{
  "statusCode": 200,
  "headers": {
    "Content-Type": "application/json"
  },
  "body": {
    "result": "success",
    "username": "JohnDoe"
  }
}
*/
// If unsuccessful, returns:
/*
{
  "statusCode": 400,
  "headers": {
    "Content-Type": "application/json"
  },
  "body": {
    "result": "failure",
    "error": "The error message."
  }
}
*/

'use strict';

exports.handler = (event, context, callback) => {

  var jwt = require('jsonwebtoken');    // npm install jsonwebtoken. See https://www.npmjs.com/package/jsonwebtoken
  var request = require('request');     // npm install request. See https://www.npmjs.com/package/request
  var jwkToPem = require('jwk-to-pem'); // npm jwk-to-pem. See https://www.npmjs.com/package/jwk-to-pem
  
  // Get the JWT Set for the user pool. In this case, get it from
  // https://cognito-idp.us-west-2.amazonaws.com/us-west-2_oa6IReZxl/.well-known/jwks.json.
  var iss = 'https://cognito-idp.us-west-2.amazonaws.com/us-west-2_oa6IReZxl';
  var pems;

  if (!pems) {
    // Download the JWK Set and save it as PEM.
    request({
        url: iss + '/.well-known/jwks.json',
        json: true
      }, function (error, response, body) {
        if (!error && response.statusCode === 200) {
          
          pems = {};
          var keys = body['keys'];
          
          for(var i = 0; i < keys.length; i++) {
            // Convert each key to PEM.
            var key_id = keys[i].kid;
            var modulus = keys[i].n;
            var exponent = keys[i].e;
            var key_type = keys[i].kty;
            var jwk = { kty: key_type, n: modulus, e: exponent};
            var pem = jwkToPem(jwk);
            pems[key_id] = pem;
          }
          
          // Now continue with validating the token.
          ValidateToken(pems, event, context);
        } else {
          // Unable to download JWK Set, fail the call.
          callback(null, {
            "statusCode": response.statusCode,
            "headers": { "Content-Type": "application/json" },
            "body": {
              "result": "failure",
              "error": "Cannot download JWT Set."    
            }
          });
          return;
        }
    });
  } else {
    // PEMs are already downloaded, continue with validating the token,
    ValidateToken(pems, event, context);
  }
  
  function ValidateToken(pems, event, context) {

    var token = event["AccessToken"];
    
    var decodedJwt = jwt.decode(token, {complete: true});
    
    // Fail if the token is not JWT.
    if (!decodedJwt) {
      callback(null, {
        "statusCode": 400,
        "headers": { "Content-Type": "application/json" },
        "body": {
          "result": "failure",
          "error": "Invalid JWT format."    
        }
      });
      return;
    }

    // Fail if the token is not from your Cognito user pool.
    if (decodedJwt.payload.iss != iss) {
      callback(null, {
        "statusCode": 400,
        "headers": { "Content-Type": "application/json" },
        "body": {
          "result": "failure",
          "error": "JWT issuer does not match."    
        }
      });
      return;
    }

    // Reject the JWT if it's not an access token.
    if (decodedJwt.payload.token_use != 'access') {
      callback(null, {
        "statusCode": 400,
        "headers": { "Content-Type": "application/json" },
        "body": {
          "result": "failure",
          "error": "Not a JWT access token."    
        }
      });
      return;
    }
    
    // Reject the JWT if it's expired.
    if (decodedJwt.payload.exp < Math.floor(Date.now() / 1000)) {
      callback(null, {
        "statusCode": 400,
        "headers": { "Content-Type": "application/json" },
        "body": {
          "result": "failure",
          "error": "Expired JWT access token."    
        }
      });
      return;
    }

    // Get the kid from the token and retrieve the corresponding PEM.
    var kid = decodedJwt.header.kid;
    var pem = pems[kid];
    
    if (!pem) {
      callback(null, {
        "statusCode": 400,
        "headers": { "Content-Type": "application/json" },
        "body": {
          "result": "failure",
          "error": "kid values do not match."    
        }
      });
      return;
    }

    // Verify the signature of the JWT token to ensure it's really coming from your Cognito User Pool.
    jwt.verify(token, pem, { issuer: iss }, function(err, payload) {
      if(err) {
        callback(null, {
          "statusCode": 400,
          "headers": { "Content-Type": "application/json" },
          "body": {
            "result": "failure",
            "error": "Invalid JWT signature."    
          }
        });
        return;
      } else {
        callback(null, {
          "statusCode": 200,
          "headers": { "Content-Type": "application/json" },
          "body": {
            "result": "success",
            "username": decodedJwt.payload.username    
          }
        });
      }
    });
  }
};

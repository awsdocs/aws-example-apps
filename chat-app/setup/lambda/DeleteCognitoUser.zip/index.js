// Removes a user from the Cognito ChatRoomPool user pool.
// Requires an access token. To get one, call SignInCognitoUser.
// Input:
/*
{
  "AccessToken": "a1b2c3.d4e5f6.g7h8i9"
}
*/
// Output:
// If successful, returns:
/*
{
  "statusCode": 200,
  "headers": {
    "Content-Type": "application/json"
  },
  "body": {
    "result": "success"
  }
}
*/
// If unsuccessful, returns:
/*
{
  "statusCode": 400,
  "headers": { 
    "Content-Type": "application/json" 
  },
  "body": {
    "result": "failure",
    "error": "The error message."    
  }
}
*/

'use strict';

exports.handler = (event, context, callback) => {
  var AWS = require('aws-sdk');
  var lambda = new AWS.Lambda({apiVersion: '2015-03-31'});
  var params = {
    FunctionName: "VerifyCognitoSignIn",
    Payload: '{"AccessToken":"' + event["AccessToken"] + '"}'
  };
 
  // Verify the provided access token by calling the 
  // VerifyCognitoSignIn Lambda function.
  lambda.invoke(params, function(err, data) {
    if (err) {
      callback(null, {
        "statusCode": err["statusCode"],
        "headers": { "Content-Type": "application/json" },
        "body": {
          "result": "failure",
          "error": err    
        }
      }); 
      return;
    } else {
      var parsedJSON = JSON.parse(data["Payload"]);
      
      // If the access token could not be verified, return the error.
      if (parsedJSON["statusCode"] != 200) {
        callback(null, {
          "statusCode": parsedJSON["statusCode"],
          "headers": { "Content-Type": "application/json" },
          "body": {
            "result": parsedJSON["body"]["result"],
            "error": parsedJSON["body"]["error"]    
          }
        });
        return;
      } else {
        // Token was verified. Delete the user from the Cognito ChatRoomPool user pool.
        var provider = new AWS.CognitoIdentityServiceProvider();
  
        var params = {
          AccessToken: event["AccessToken"]
        }     

        provider.deleteUser(params, function(err, data) {
          if (err) {
            callback(null, {
              "statusCode": err["statusCode"],
              "headers": { "Content-Type": "application/json" },
              "body": {
                "result": "failure",
                "error": err    
              }
            });    
          } else {
            callback(null, {
              "statusCode": 200,
              "headers": { "Content-Type": "application/json" },
              "body": {
                "result": "success"
              }
            });        
          }
        });
      }
    }
  });
};
// Adds a pending user to the ChatRoomPool Cognito user pool.
// To confirm the pending user, call FinishAddingPendingCognitoUser.

// Input JSON:
/*
{
  "UserName": "JohnDoe",
  "Password": "123456",
  "Email": "johndoe@example.com"
}
*/
// Output: 
// If successful, returns:
/*
{
  "statusCode": 200,
  "headers": {
    "Content-Type": "application/json"
  },
  "body": {
    "result": "success",
    "data": {
      "UserConfirmed": false,
      "CodeDeliveryDetails": {
        "Destination": "...",
        "DeliveryMedium": "EMAIL",
        "AttributeName": "email"
      }
    }
  }
}
*/
// If unsuccessful, returns:
/*
{
  "statusCode": 400,
  "headers": {
    "Content-Type": "application/json"
  },
  "body": {
    "result": "failure",
    "error": {
      "message": "User already exists",
      "code": "UsernameExistsException",
      "time": "...",
      "requestId": "...",
      "statusCode": 400,
      "retryable": false,
      "retryDelay": ...
    }
  }
}
*/

'use strict';

exports.handler = (event, context, callback) => {
  var AWS = require('aws-sdk');
  var provider = new AWS.CognitoIdentityServiceProvider();
  
  var params = {
    ClientId: "506vmurlsgu8qp35qjr8n0lpkn",
    Username: event["UserName"],
    Password: event["Password"],
    UserAttributes: [
      {
        "Name": "email",
        "Value": event["Email"]
      }     
    ]
  };
  
  provider.signUp(params, function(err, data) {
    if (err) {
      callback(null, {
        "statusCode": err["statusCode"],
        "headers": { "Content-Type": "application/json" },
        "body": {
          "result": "failure",
          "error": err    
        }
      });    
    } else {
      callback(null, {
        "statusCode": 200,
        "headers": { "Content-Type": "application/json" },
        "body": {
          "result": "success",
          "data": data
        }
      });        
    }
  });
};
// Finishes changing a user's previously-forgotten password in the ChatRoomPool Cognito user pool.
// To begin the change, call StartChangingForgottenCognitoUserPassword.
/*
{
  "UserName": "JohnDoe",
  "ConfirmationCode": "123456",
  "NewPassword": "987654"
}
*/
// Output: 
// If successful, returns:
/*
{
  "statusCode": 200,
  "headers": {
    "Content-Type": "application/json"
  },
  "body": {
    "result": "success"
  }
}
*/
// If unsuccessful, returns:
/*
{
  "statusCode": 400,
  "headers": {
    "Content-Type": "application/json"
  },
  "body": {
    "result": "failure",
    "error": {
      "message": "Invalid code provided, please request a code again.",
      "code": "ExpiredCodeException",
      "time": "...",
      "requestId": "...",
      "statusCode": 400,
      "retryable": false,
      "retryDelay": ...
    }
  }
}
*/
// Or...
/*
{
  "statusCode": 400,
  "headers": {
    "Content-Type": "application/json"
  },
  "body": {
    "result": "failure",
    "error": {
      "message": "Invalid verification code provided, please try again.",
      "code": "CodeMismatchException",
      "time": "...",
      "requestId": "...",
      "statusCode": 400,
      "retryable": false,
      "retryDelay": 39.164924699150646
    }
  }
}
*/

'use strict';

exports.handler = (event, context, callback) => {
  var AWS = require('aws-sdk');
  var provider = new AWS.CognitoIdentityServiceProvider();
  
  var params = {
    ClientId: "506vmurlsgu8qp35qjr8n0lpkn",
    Username: event["UserName"],
    ConfirmationCode: event["ConfirmationCode"],
    Password: event["NewPassword"]
  };
  
  provider.confirmForgotPassword(params, function(err, data) {
    if (err) {
      callback(null, {
        "statusCode": err["statusCode"],
        "headers": { "Content-Type": "application/json" },
        "body": {
          "result": "failure",
          "error": err    
        }
      });    
    } else {
      callback(null, {
        "statusCode": 200,
        "headers": { "Content-Type": "application/json" },
        "body": {
          "result": "success"
        }
      });        
    }
  });
};
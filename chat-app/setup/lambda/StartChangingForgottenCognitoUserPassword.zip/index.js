// Begins changing a user's forgotten password in the ChatRoomPool Cognito user pool.
// To complete the change, call FinishChangingForgottenCognitoUserPassword.

// Input JSON:
/*
{
  "UserName": "JohnDoe"
}
*/
// Output: 
// If successful, returns:
/*
{
  "statusCode": 200,
  "headers": {
    "Content-Type": "application/json"
  },
  "body": {
    "result": "success",
    "data": {
      "CodeDeliveryDetails": {
        "Destination": "...",
        "DeliveryMedium": "EMAIL",
        "AttributeName": "email"
      }
    }
  }
}
*/
// If unsuccessful, returns:
/*
{
  "statusCode": 400,
  "headers": {
    "Content-Type": "application/json"
  },
  "body": {
    "result": "failure",
    "error": {
      "message": "Username/client id combination not found.",
      "code": "UserNotFoundException",
      "time": "...",
      "requestId": "...",
      "statusCode": 400,
      "retryable": false,
      "retryDelay": ...
    }
  }
}
*/

'use strict';

exports.handler = (event, context, callback) => {
  var AWS = require('aws-sdk');
  var provider = new AWS.CognitoIdentityServiceProvider();
  
  var params = {
    ClientId: "506vmurlsgu8qp35qjr8n0lpkn",
    Username: event["UserName"]
  };
  
  provider.forgotPassword(params, function(err, data) {
    if (err) {
      callback(null, {
        "statusCode": err["statusCode"],
        "headers": { "Content-Type": "application/json" },
        "body": {
          "result": "failure",
          "error": err    
        }
      });    
    } else {
      callback(null, {
        "statusCode": 200,
        "headers": { "Content-Type": "application/json" },
        "body": {
          "result": "success",
          "data": data
        }
      });        
    }
  });
};
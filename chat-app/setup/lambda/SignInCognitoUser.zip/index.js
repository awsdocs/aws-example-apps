// Signs in a user to the ChatRoomPool Cognito user pool.
// Input:
/*
{
  "UserName": "JohnDoe",
  "Password": "123456"
}
*/
// Output: 
// If successful, returns:
/*
{
  "statusCode": 200,
  "headers": {
    "Content-Type": "application/json"
  },
  "body": {
    "result": "success",
    "data": {
      "ChallengeParameters": {},
      "AuthenticationResult": {
        "AccessToken": "eyJraWQi.BkgbxTA-J.Ab_A2P7jR",
        "ExpiresIn": 3600,
        "TokenType": "Bearer",
        "RefreshToken": "eyJjdHki.NcdYrLsE.UL_596I8q",
        "IdToken": "eyJraWQi.eyJzdWIi.iATBko4Q"
      }
    }
  }
}
*/
// If unsuccessful, returns:
/*
{
  "statusCode": xxx,
  "headers": {
    "Content-Type": "application/json"
  },
  "body": {
    "result": "failure",
    "error": {
      "message": "User does not exist.",
      "code": "UserNotFoundException",
      "time": "...",
      "requestId": "...",
      "statusCode": 400,
      "retryable": false,
      "retryDelay": ...
    }
  }
}
*/
// Or...
/*
{
  "statusCode": xxx,
  "headers": {
    "Content-Type": "application/json"
  },
  "body": {
    "result": "failure",
    "error": {
      "message": "Incorrect username or password.",
      "code": "NotAuthorizedException",
      "time": "...",
      "requestId": "...",
      "statusCode": 400,
      "retryable": false,
      "retryDelay": ...
    }
  }
}
*/

'use strict';

exports.handler = (event, context, callback) => {
  var AWS = require('aws-sdk');
  var provider = new AWS.CognitoIdentityServiceProvider();
  
  var params = {
    UserPoolId: "us-west-2_oa6IReZxl",
    ClientId: "506vmurlsgu8qp35qjr8n0lpkn",
    AuthFlow: "ADMIN_NO_SRP_AUTH",
    AuthParameters: {
      "USERNAME": event["UserName"],
      "PASSWORD": event["Password"]
    }
  };
  
  provider.adminInitiateAuth(params, function(err, data) {
    if (err) {
      callback(null, {
        "statusCode": err["statusCode"],
        "headers": { "Content-Type": "application/json" },
        "body": {
          "result": "failure",
          "error": err    
        }
      });    
    } else {
      callback(null, {
        "statusCode": 200,
        "headers": { "Content-Type": "application/json" },
        "body": {
          "result": "success",
          "data": data
        }
      });        
    }
  });
};
// Confirms a pending user in the ChatRoomPool Cognito user pool.
// To add a pending user, call StartAddingPendingCognitoUser.

// Input JSON:
/*
{
  "UserName": "JohnDoe",
  "ConfirmationCode": "123456"
}
*/
// Output: 
// If successful, returns:
/*
{
  "statusCode": 200,
  "headers": {
    "Content-Type": "application/json"
  },
  "body": {
    "result": "success"
  }
}
*/
// If unsuccessful, returns:
/*
{
  "statusCode": 400,
  "headers": {
    "Content-Type": "application/json"
  },
  "body": {
    "result": "failure",
    "error": {
      "message": "Username/client id combination not found.",
      "code": "UserNotFoundException",
      "time": "...",
      "requestId": "...",
      "statusCode": 400,
      "retryable": false,
      "retryDelay": ...
    }
  }
}
*/
// Or...
/*
{
  "statusCode": 400,
  "headers": {
    "Content-Type": "application/json"
  },
  "body": {
    "result": "failure",
    "error": {
      "message": "Invalid verification code provided, please try again.",
      "code": "CodeMismatchException",
      "time": "...",
      "requestId": "...",
      "statusCode": 400,
      "retryable": false,
      "retryDelay": ...
    }
  }
}
*/

'use strict';

exports.handler = (event, context, callback) => {
  var AWS = require('aws-sdk');
  var provider = new AWS.CognitoIdentityServiceProvider();
  
  var params = {
    ClientId: "506vmurlsgu8qp35qjr8n0lpkn",
    Username: event["UserName"],
    ConfirmationCode: event["ConfirmationCode"]
  };
  
  provider.confirmSignUp(params, function(err, data) {
    if (err) {
      callback(null, {
        "statusCode": err["statusCode"],
        "headers": { "Content-Type": "application/json" },
        "body": {
          "result": "failure",
          "error": err    
        }
      });    
    } else {
      callback(null, {
        "statusCode": 200,
        "headers": { "Content-Type": "application/json" },
        "body": {
          "result": "success"
        }
      });        
    }
  });
};
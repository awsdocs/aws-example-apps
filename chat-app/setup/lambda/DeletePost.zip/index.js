// Deletes a post from the Posts table in DynamoDB.
// Requires an access token. To get one, call SignInCognitoUser.
// Input:
/*
{
  "AccessToken": "a1b2c3.d4e5f6.g7h8i9",
  "TimestampOfPost": "1496181005"
}
*/
// Output:
// If successful, returns:
/*
{
  "statusCode": 200,
  "headers": {
    "Content-Type": "application/json"
  },
  "body": {
    "result": "success"
  }
}
*/
// If unsuccessful, returns:
/*
{
  "statusCode": 400,
  "headers": { 
    "Content-Type": "application/json" 
  },
  "body": {
    "result": "failure",
    "error": "The error message."    
  }
}
*/

'use strict';

exports.handler = (event, context, callback) => {
  var AWS = require('aws-sdk');
  var lambda = new AWS.Lambda({apiVersion: '2015-03-31'});
  var params = {
    FunctionName: "VerifyCognitoSignIn",
    Payload: '{"AccessToken":"' + event["AccessToken"] + '"}'
  };
 
  // Verify the provided access token by calling the 
  // VerifyCognitoSignIn Lambda function.
  lambda.invoke(params, function(err, data) {
    // Lambda function could not be successfully invoked.
    if (err) {
      callback(null, {
        "statusCode": err["statusCode"],
        "headers": { "Content-Type": "application/json" },
        "body": {
          "result": "failure",
          "error": err    
        }
      }); 
      return;
    } else {
      var parsedJSON = JSON.parse(data["Payload"]);
      
      // If the access token could not be verified, return the error.
      if (parsedJSON["statusCode"] != 200) {
        callback(null, {
          "statusCode": parsedJSON["statusCode"],
          "headers": { "Content-Type": "application/json" },
          "body": {
            "result": parsedJSON["body"]["result"],
            "error": parsedJSON["body"]["error"]    
          }
        });
        return;
      } else {
        // Token was verified. Attempt to delete the matching post from the 
        // Posts table in DynamoDB.
        var dynamoDB = new AWS.DynamoDB();
        var params = {
          TableName: "Posts",
          Key: {
            Alias: { "S": parsedJSON["body"]["username"] },
            Timestamp: { "S": event["TimestampOfPost"] }
          },
          ReturnValues: "ALL_OLD"
        };
  
        dynamoDB.deleteItem(params, function(err, data) {
          // Could not successfully call the deleteItem method.
          if (err) {
            callback(null, {
              "statusCode": err["statusCode"],
              "headers": { "Content-Type": "application/json" },
              "body": {
                "result": "failure",
                "error": err    
              }
            });
            return;
          } else {
            // Check to see if a matching item in the table was actually deleted.
            // If no item attributes are returned, or if the returned attributes do not
            // match those that were originally provided, then assume 
            // no matching item was found, and return an error. 
            if (data["Attributes"] == null || 
              !(data["Attributes"]["Alias"]["S"] == parsedJSON["body"]["username"] && 
                data["Attributes"]["Timestamp"]["S"] == event["TimestampOfPost"])) {
              callback(null, {
                "statusCode": 400,
                "headers": { "Content-Type": "application/json" },
                "body": {
                  "result": "failure",
                  "error": "No matching items to delete."
                }
              });
              return;
            } else {
              callback(null, {
                "statusCode": 200,
                "headers": { "Content-Type": "application/json" },
                "body": {
                  "result": "success"
                }
              });
            }
          }
        });
      }
    }
  });
};